import UIKit

// arithmetic operatiors x-=y x+=y x*=y x/=y is same as x=x-y and so on
// division (/) gives the integer or float based on the variables
// reminder/modulo (%) gives the remonder of the division


// area of a triangle
var length: Double = 10
var width: Double = 5
// a^2 + b^2 = c^2
// pow(variable,power) is the suntax for power of a variable
// squareroot(variable)
let areaTriangle = sqrt(pow(length,2) + pow(width,2))
print("area of a triange of length \(length) and width \(width) is ", Double(areaTriangle))

// remember we cannot use two different types to perform operations as it gives a type error thus we can use type casting to change a variables type

// conditional == != > >= < <=
// boolean || -or

// if if-else elseif statement follow the same syntax as python but we use brackets here than indentation
var a = 10
var b = 20
var c = 30
if a == b
{
    print(" Yes a is equal to b")
}
else if b == c
{
    print("yes, b is equal to c")
}
else
{
        print("No, both a and b are not equal to c")
}



