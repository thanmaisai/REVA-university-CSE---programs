import UIKit

// printing hello world
// var greeting = "Hello, playground"
// print(greeting)

// swift has string integer double boolean as datatypes
// var is used for variable
var name = "thanmai"
var age = 19
var weight = 56.5
var isOrganDonar  = false
weight = 55.6
print(name,age,weight,isOrganDonar)


// let is used for a constant
let eyecolour = "brown"
// eyecolour = "green" // this will throw an error as constants cannot be changed

// type's of decletarion
var str = "hello world" // type inference (implecit)
var message: String = "this is a string" // Explicit type
// var amessage: String = 10 // Error: as 10 is an integer

// string concatination
let firstname = "thanmai"
let lastname = "sai"
var fullname = firstname + " " + lastname
print(fullname)

var myage = 19
var bmessage: String = "Hi, my name is \(firstname) and i am \(age) year's old. "
    // string interpolation
print(bmessage)
// appending a new string to the old existing string(bmessage)
bmessage.append("And i like scary clowns")
print(bmessage)




