import UIKit

// arrays
var a = 1
var b = 2
var c = 3
var d = 4
var e = 5
var f = 6


// var num = [1,2,3,4,5,6]
var num: [Double] = [1,2,3,4,5,6]
// gives the type of the array
type(of: num)
// count returns number of elements on the array
print(num.count)
// append adds a element at the last of the array
num.append(7)
print(num.count)
// remove(at: ) removes the element at the index entered
num.remove(at: 2)
//num.removeAll() removes all the elements in the array
print(num)

// loops syntax

// while loop
var x = 0
repeat{
    x = x+1
}while(x < num.count)
print("using while loop ",x)
        
// for-in loop
var y = 0
for i in 0..<num.count{
    y = y+1
}
print("using for loop ",y)

for xyz in num{
    print("num:  \(xyz)")
}

// array(list of elements),set(unique and unordered),dictonaries(keys and value pairs)

// dictionaries (or) hash table


